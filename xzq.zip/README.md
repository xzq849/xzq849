<div id="title" align=center>

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=xzq849&show_icons=true&theme=radical)

### 不想学习🤣🤣

[![知乎](https://img.shields.io/badge/%E7%9F%A5%E4%B9%8E-mq%E7%99%BD-yello)](https://www.zhihu.com/people/o4ze4r)
[![youtube](https://img.shields.io/badge/video-YouTube-red)](https://www.youtube.com/channel/UCey35Do4RGewqr-6EiaCJrg)

[![modern cpp](https://img.shields.io/badge/code-Modern%20C++-blue)](https://learn.microsoft.com/zh-cn/cpp/cpp/welcome-back-to-cpp-modern-cpp) 
![](https://img.shields.io/badge/讨厌-学习-yellow) 
![](https://img.shields.io/badge/性格-开朗-red) 
![](https://img.shields.io/badge/爱好-二次元-red)

</div>

![头像](image/头像.jpg)

![Visitor Count](https://profile-counter.glitch.me/Mq-b/count.svg)